package Lab1;


/**
 * An account (e.g. savings account) to be used for demonstration.
 * 
 * @author COMP1161
 * @version January 2015
 */
public class Account
{
    private double balance;
    
    
    /**
     * Constructor #1 - Account balance set to 0.00
     */
    public Account()
    {
        balance = 0.0;
    }
   
    /**
     * Constructor #2 - Set account balance to specified amount
     * @param amt amount that the balance is to set to 
     */
    public Account(double amt)
    {
        balance = amt;
    }
 
    
    /**
     * Deposit an amount to the account.
     * @param amt amount to be deposited
     */
    public void deposit(double amt)
    {
        balance += amt;
    }
    
    
    
    /**
     * Withdraw an amount from the account.
     * @param amt amount to be withdrawn
     */
    public void withdraw(double amt)
    {
            balance -= amt;
    }
    
    
    /**
     * Return account balance
     * @param amt amount to be withdrawn
     * @return amount of money in the account (balance)
     */
    public double balance()
    {
        return balance;
    }
   
    /**
      * Return textual representation of an account
      * @param none
      * @return formatted string with information about the object
      */
    public String toString
    {
       return "[" + this.balance + "]";
    }
    
}
